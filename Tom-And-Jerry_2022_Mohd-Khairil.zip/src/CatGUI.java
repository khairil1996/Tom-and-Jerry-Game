// PLEASE RUN THE CatGUI.java!!
public class CatGUI {
    public static void main(String[] args) {


        CatFrame cf = new CatFrame("Tom and Jerry");
    cf.setVisible(true);
    }
    }


